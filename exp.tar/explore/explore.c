#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void){
	FILE* fp = fopen("data.txt", "r");

	if(fp==NULL) exit(0);

	char buf[100];
	for(int i=0;i<54;++i){	
		fscanf(fp, "%s", buf);
		char cmd[1000] = "ls -al /home/ITE1015_";
		strcat(cmd, buf);
		strcat(cmd, "/ite1015_");
		strcat(cmd, buf);
		system(cmd);
	}
	fclose(fp);
	return 0;
}
